#!/bin/bash
# Railway Backend Deployment - FOR THE KIDS
set -e

echo "🚀 Deploying backend to Railway..."

# Package backend for deployment
tar -czf backend-deploy.tar.gz \
  --exclude='node_modules' \
  --exclude='*.tar.gz' \
  --exclude='.env' \
  server.js package.json package-lock.json \
  routes/ services/ middleware/ utils/ railway.json

echo "✅ Backend packaged"
echo "📦 Size: $(du -h backend-deploy.tar.gz | cut -f1)"
echo ""
echo "Railway project: aicollabforthekids-production"
echo "🌐 Will be available at: https://aicollabforthekids-production.up.railway.app"
echo ""
echo "⚠️ IMPORTANT: Set environment variables in Railway dashboard:"
echo "   - GEMINI_API_KEY"
echo "   - SQUARE_ACCESS_TOKEN"
echo "   - JWT_SECRET"
echo "   - DATABASE_URL (auto-provided by Postgres plugin)"
echo ""
echo "FOR THE KIDS 🚀"
